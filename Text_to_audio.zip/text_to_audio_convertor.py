from tkinter import*
from tkinter import messagebox ,filedialog
import os
from tkinter import ttk
import pyttsx3

def spe():
    tex = pyttsx3.init()
    ans = text.get(1.0,END)
    a = combo1.get()
    b = combo2.get()
    if a == "Male":
        voices = tex.getProperty('voices')
        tex.setProperty("voice",voices[0].id)
    elif a == "Female":
        voices = tex.getProperty('voices')
        tex.setProperty("voice",voices[1].id)
    if b == "Normal":
        tex.setProperty("rate",150)
    elif b == "Slow":
        tex.setProperty("rate",100)
    elif b == "Fast":
        tex.setProperty("rate",250)
    elif b == "Too Fast":
        tex.setProperty("rate",300)
    tex.say(ans)
    tex.runAndWait()
def save():
    tex = pyttsx3.init()
    ans = text.get(1.0,END)
    a = combo1.get()
    b = combo2.get()
    if a == "Male":
        voices = tex.getProperty('voices')
        tex.setProperty("voice",voices[0].id)

    elif a == "Female":
        voices = tex.getProperty('voices')
        tex.setProperty("voice",voices[1].id)

    if b == "Normal":
        tex.setProperty("rate",150)

    elif b == "Slow":
        tex.setProperty("rate",100)

    elif b == "Fast":
        tex.setProperty("rate",250)

    elif b == "Too Fast":
        tex.setProperty("rate",300)

    path = filedialog.askdirectory()
    os.chdir(path)
    tex.save_to_file(ans,"text.mp3")
    tex.runAndWait()   


root = Tk()
root.geometry("777x401")
root.resizable(0,0)
img = PhotoImage(file= "back.png")
img1 = PhotoImage(file= "mic.png")
back = Label(root,image=img).pack()
mic = Label(root,image=img1).place(x = 10,y = 10)
lb= Label(root,text = "Text To Audio Convertor",font=("verdana 30 bold"),padx=60,bg ="#041424",fg = "brown").place(x = 100,y = 15)
text = Text(root,background ="powder blue", font=("verdana 11 bold"),relief=GROOVE,wrap=WORD,borderwidth=0)
text.place(x = 20,y = 100,width = 450,height=280)
sc = Scrollbar(text)
sc.pack(side=RIGHT,fill=Y)
sc.config(command=text.yview)
text.config(yscrollcommand=sc.set)

voi = ["Male","Female"]
combo1 = ttk.Combobox(root,values=voi,font="Roboto 12",state="r",width=8)
combo1.place(x = 520,y = 140)
combo1.set("Male")



sp = ["Slow","Normal","Fast","Too Fast"]
combo2= ttk.Combobox(root,values=sp,font="Roboto 12",state="r",width=8)
combo2.place(x = 640,y = 140)
combo2.set("Normal")

lb1= Label(root,text = "Gender",font=("verdana 14 bold"),bg ="#041424",fg = "brown").place(x = 525,y = 100)
lb2= Label(root,text = "Speed",font=("verdana 14 bold"),bg ="#041424",fg = "brown").place(x = 650,y = 100)

btn = Button(root,text = "Speak",padx=15,pady=4,bg = "powder blue",borderwidth=3,command=spe,fg = "black",font=("verdana 10 bold")).place(x = 523,y = 200)
btn1 = Button(root,text = "Save",padx=15,pady=4,bg = "powder blue",borderwidth=3,command=save,fg = "black",font=("verdana 10 bold")).place(x = 647,y = 200)
root.mainloop()